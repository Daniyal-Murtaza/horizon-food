<?php

$db_name = 'mysql:host=localhost;dbname=u795647042_food';
$user_name = 'u795647042_daniyal';
$user_password = 'Pakistan772';

$conn = new PDO($db_name, $user_name, $user_password);

?>